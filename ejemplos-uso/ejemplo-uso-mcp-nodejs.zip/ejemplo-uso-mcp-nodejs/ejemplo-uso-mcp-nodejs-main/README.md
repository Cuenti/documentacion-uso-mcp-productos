# Cliente MCP en Node.js + TypeScript (Ejemplo Reutilizable)

Este proyecto muestra una estructura base para consumir un servidor MCP desde Node.js con TypeScript mediante una clase de alto nivel.

## Estructura

- `src/mcp-cuenti-productos.ts`: cliente reusable con métodos de alto nivel.
- `src/main.ts`: ejemplo mínimo de uso cargando variables desde `.env`.

## Requisitos

- Node.js 18+

## Instalación

### npm

```bash
npm install
```

### pnpm

```bash
pnpm install
```

### yarn

```bash
yarn install
```

### bun

```bash
bun install
```

## Configuración

```bash
cp .env.example .env
```

Completa las variables requeridas:

- `MCP_API_TOKEN`
- `MCP_COMPANY_ID`
- `MCP_BRANCH_ID`
- `MCP_EMPLOYEE_ID`
- `MCP_QUERY`
- `MCP_TOP_K`

## Ejecución

### npm

```bash
npm run start
```

### pnpm

```bash
pnpm start
```

### yarn

```bash
yarn start
```

### bun

```bash
bun run start
```

## Reutilizar en otro proyecto

Puedes copiar y pegar `src/mcp-cuenti-productos.ts` en cualquier proyecto TypeScript.

Dependencias mínimas en el proyecto destino:

- `@modelcontextprotocol/sdk`

Ejemplo:

```ts
import { MCPCuentiProductos } from "./mcp-cuenti-productos";

const client = new MCPCuentiProductos({
  apiToken: "<api_token>",
  companyId: "<company_id>",
  branchId: "<branch_id>",
  employeeId: "<employee_id>"
});

await client.connect();
try {
  const result = await client.searchProducts("arroz", 5);
  console.log(result);
} finally {
  await client.close();
}
```

