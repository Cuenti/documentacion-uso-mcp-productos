import "dotenv/config";
import { MCPCuentiProductos } from "./mcp-cuenti-productos.js";

const REQUIRED_ENV_VARS = [
  "MCP_API_TOKEN",
  "MCP_COMPANY_ID",
  "MCP_BRANCH_ID",
  "MCP_EMPLOYEE_ID",
  "MCP_QUERY",
  "MCP_TOP_K"
] as const;

function getRequiredEnv(name: (typeof REQUIRED_ENV_VARS)[number]): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(`Falta la variable de entorno requerida: ${name}`);
  }
  return value;
}

async function main(): Promise<void> {
  const missing = REQUIRED_ENV_VARS.filter((name) => !process.env[name]);
  if (missing.length > 0) {
    throw new Error(`Faltan variables requeridas en .env: ${missing.join(", ")}. Revisa .env.example`);
  }

  const mcpClient = new MCPCuentiProductos({
    apiToken: getRequiredEnv("MCP_API_TOKEN"),
    companyId: getRequiredEnv("MCP_COMPANY_ID"),
    branchId: getRequiredEnv("MCP_BRANCH_ID"),
    employeeId: getRequiredEnv("MCP_EMPLOYEE_ID")
  });

  const query = getRequiredEnv("MCP_QUERY");
  const topK = Number.parseInt(getRequiredEnv("MCP_TOP_K"), 10);

  await mcpClient.connect();
  try {
    const tools = await mcpClient.listTools();
    console.log("Tools disponibles:", tools);
    console.log("Request ID generado:", mcpClient.requestId);

    const payload = await mcpClient.searchProducts(query, topK);
    console.log(JSON.stringify(payload, null, 2));
  } finally {
    await mcpClient.close();
  }
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
