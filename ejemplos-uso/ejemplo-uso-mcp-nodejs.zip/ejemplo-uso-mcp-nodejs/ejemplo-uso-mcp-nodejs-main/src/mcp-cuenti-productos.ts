import { randomUUID } from "node:crypto";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";

const MCP_URL = "https://mcp-productos.cuenti.co/mcp/";

export type SearchProductsResult = Record<string, unknown>;

export class MCPCuentiProductos {
  public readonly requestId: string;

  private readonly client: Client;
  private readonly transport: StreamableHTTPClientTransport;

  constructor(params: {
    apiToken: string;
    companyId: string;
    branchId: string;
    employeeId: string;
    requestId?: string;
  }) {
    this.requestId = params.requestId ?? randomUUID();

    this.client = new Client({
      name: "mcp-cuenti-productos-node-client",
      version: "0.1.0"
    });

    this.transport = new StreamableHTTPClientTransport(new URL(MCP_URL), {
      requestInit: {
        headers: {
          Authorization: `Bearer ${params.apiToken}`,
          "X-Auth-Token-Empresa": params.companyId,
          "X-Branch-Id": params.branchId,
          "X-Employee-Id": params.employeeId,
          "X-Request-Id": this.requestId
        }
      }
    });

    this.companyId = params.companyId;
    this.branchId = params.branchId;
  }

  private readonly companyId: string;
  private readonly branchId: string;

  async connect(): Promise<void> {
    await this.client.connect(this.transport);
  }

  async close(): Promise<void> {
    await this.client.close();
  }

  async listTools(): Promise<string[]> {
    const response = await this.client.listTools();
    return response.tools.map((tool) => tool.name);
  }

  async searchProducts(query: string, topK = 5): Promise<SearchProductsResult> {
    const response = await this.client.callTool({
      name: "search_products",
      arguments: {
        company_id: this.companyId,
        branch_id: this.branchId,
        query,
        top_k: topK
      }
    });

    return this.extractPayload(response);
  }

  async lookupBySku(sku: string): Promise<SearchProductsResult> {
    const response = await this.client.callTool({
      name: "lookup_products",
      arguments: {
        company_id: this.companyId,
        branch_id: this.branchId,
        sku
      }
    });

    return this.extractPayload(response);
  }

  async semanticSearchProducts(denseVector: number[], topK = 5): Promise<SearchProductsResult> {
    const response = await this.client.callTool({
      name: "semantic_search_products",
      arguments: {
        company_id: this.companyId,
        branch_id: this.branchId,
        dense_vector: denseVector,
        top_k: topK
      }
    });

    return this.extractPayload(response);
  }

  async hybridSearchProducts(params: {
    normalizedQuery: string;
    denseVector: number[];
    sparseIndices: number[];
    sparseValues: number[];
    topK?: number;
  }): Promise<SearchProductsResult> {
    const response = await this.client.callTool({
      name: "hybrid_search_products",
      arguments: {
        company_id: this.companyId,
        branch_id: this.branchId,
        normalized_query: params.normalizedQuery,
        dense_vector: params.denseVector,
        sparse_indices: params.sparseIndices,
        sparse_values: params.sparseValues,
        top_k: params.topK ?? 5
      }
    });

    return this.extractPayload(response);
  }

  private extractPayload(response: unknown): SearchProductsResult {
    if (!response || typeof response !== "object") {
      throw new Error("El MCP no devolvio payload util.");
    }

    const maybeStructured = (response as { structuredContent?: unknown }).structuredContent;
    if (maybeStructured && typeof maybeStructured === "object") {
      return maybeStructured as SearchProductsResult;
    }

    const maybeToolResult = (response as { toolResult?: unknown }).toolResult;
    if (maybeToolResult && typeof maybeToolResult === "object") {
      return maybeToolResult as SearchProductsResult;
    }

    const maybeContent = (response as { content?: unknown }).content;
    if (Array.isArray(maybeContent) && maybeContent.length > 0) {
      const first = maybeContent[0] as { text?: string };
      if (first?.text) {
        try {
          const parsed = JSON.parse(first.text) as Record<string, unknown>;
          return parsed;
        } catch {
          return { raw: first.text };
        }
      }
    }

    throw new Error("El MCP no devolvio payload util.");
  }
}
