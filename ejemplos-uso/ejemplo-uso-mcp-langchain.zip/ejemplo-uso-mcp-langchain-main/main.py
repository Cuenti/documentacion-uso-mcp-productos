import asyncio
import os

from dotenv import load_dotenv

from ejemplo_langchain import MCPCuentiProductosLangChain

REQUIRED_ENV_VARS = [
    "MCP_API_TOKEN",
    "MCP_COMPANY_ID",
    "MCP_BRANCH_ID",
    "MCP_EMPLOYEE_ID",
    "MCP_QUERY",
    "MCP_TOP_K",
]


def get_required_env(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise RuntimeError(f"Falta la variable de entorno requerida: {name}")
    return value


async def main() -> None:
    load_dotenv()

    missing = [name for name in REQUIRED_ENV_VARS if not os.getenv(name)]
    if missing:
        missing_str = ", ".join(missing)
        raise RuntimeError(f"Faltan variables requeridas en .env: {missing_str}. Revisa .env.example")

    mcp_tools = MCPCuentiProductosLangChain(
        api_token=get_required_env("MCP_API_TOKEN"),
        company_id=get_required_env("MCP_COMPANY_ID"),
        branch_id=get_required_env("MCP_BRANCH_ID"),
        employee_id=get_required_env("MCP_EMPLOYEE_ID"),
    )

    tools = mcp_tools.get_tools()
    print("Tools LangChain disponibles:", [tool.name for tool in tools])

    query = get_required_env("MCP_QUERY")
    top_k = int(get_required_env("MCP_TOP_K"))

    search_tool = next(tool for tool in tools if tool.name == "search_products")
    result = await search_tool.ainvoke({"query": query, "top_k": top_k})
    print(result)


if __name__ == "__main__":
    asyncio.run(main())
