import asyncio
import os

from dotenv import load_dotenv
from langchain.agents import create_agent
from langchain_openai import ChatOpenAI
from langchain_core.messages import AIMessage, HumanMessage

from ejemplo_langchain import MCPCuentiProductosLangChain

REQUIRED_ENV_VARS = [
    "OPENROUTER_API_KEY",
    "MCP_API_TOKEN",
    "MCP_COMPANY_ID",
    "MCP_BRANCH_ID",
    "MCP_EMPLOYEE_ID",
]


def get_required_env(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise RuntimeError(f"Falta la variable de entorno requerida: {name}")
    return value


async def main() -> None:
    load_dotenv()

    missing = [name for name in REQUIRED_ENV_VARS if not os.getenv(name)]
    if missing:
        missing_str = ", ".join(missing)
        raise RuntimeError(f"Faltan variables requeridas en .env: {missing_str}. Revisa .env.example")

    mcp_tools = MCPCuentiProductosLangChain(
        api_token=get_required_env("MCP_API_TOKEN"),
        company_id=get_required_env("MCP_COMPANY_ID"),
        branch_id=get_required_env("MCP_BRANCH_ID"),
        employee_id=get_required_env("MCP_EMPLOYEE_ID"),
    )

    tools = mcp_tools.get_tools()

    model = ChatOpenAI(
        api_key=get_required_env("OPENROUTER_API_KEY"),
        base_url="https://openrouter.ai/api/v1",
        model=os.getenv("OPENROUTER_MODEL", "openai/gpt-4o-mini"),
    )

    agent = create_agent(
        model,
        tools=tools,
        system_prompt="You are a helpful assistant. Be concise and accurate.",
    )

    user_query = os.getenv(
        "AGENT_QUERY",
        "Busca productos de arroz y dame un resumen corto con precio y existencias.",
    )

    result = await agent.ainvoke(
        {
            "messages": [
                {"role": "user", "content": user_query},
            ]
        }
    )

    messages = result.get("messages", []) if isinstance(result, dict) else []
    user_message = next((m for m in messages if isinstance(m, HumanMessage)), None)
    ai_message = next((m for m in reversed(messages) if isinstance(m, AIMessage) and m.content), None)

    print("Usuario:", user_message.content if user_message else user_query)
    print("IA:", ai_message.content if ai_message else "No se obtuvo respuesta final del agente.")


if __name__ == "__main__":
    asyncio.run(main())
