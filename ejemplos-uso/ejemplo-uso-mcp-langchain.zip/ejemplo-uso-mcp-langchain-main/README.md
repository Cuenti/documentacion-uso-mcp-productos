# Cliente MCP con LangChain (Python)

Este proyecto muestra dos formas de uso con LangChain:

- ejemplo básico de tools (invocación directa)
- ejemplo con agente que decide cuándo usar las tools

## Estructura

- `src/ejemplo_langchain/mcp_cuenti_langchain.py`: clase reusable que expone tools de LangChain.
- `main.py`: ejemplo básico (invoca una tool directamente).
- `agent_main.py`: ejemplo con `create_agent(...)` usando OpenRouter.

## Instalación

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -e .
```

## Configuración

```bash
cp .env.example .env
```

Variables requeridas:

- `OPENROUTER_API_KEY` (solo para `agent_main.py`)
- `MCP_API_TOKEN`
- `MCP_COMPANY_ID`
- `MCP_BRANCH_ID`
- `MCP_EMPLOYEE_ID`
- `MCP_QUERY` (solo para `main.py`)
- `MCP_TOP_K` (solo para `main.py`)

Variables opcionales:

- `OPENROUTER_MODEL` (default: `openai/gpt-4o-mini`)
- `AGENT_QUERY` (solo para `agent_main.py`)

## Ejecutar ejemplo básico

```bash
python main.py
```

## Ejecutar ejemplo con agente (OpenRouter)

```bash
python agent_main.py
```

## Nota de arquitectura

Este repositorio deja resuelta la capa de tools MCP para LangChain. La implementación final del agente queda en manos del equipo de desarrollo, que puede usar el proveedor/modelo que prefiera (OpenAI, Claude, Gemini, OpenRouter, etc.).

## Reutilizar en otro proyecto

```python
from ejemplo_langchain import MCPCuentiProductosLangChain

client = MCPCuentiProductosLangChain(
    api_token="...",
    company_id="23621",
    branch_id="1",
    employee_id="1",
)

tools = client.get_tools()
```

La URL del MCP queda fija en el módulo y cada invocación genera un `request_id` aleatorio.
