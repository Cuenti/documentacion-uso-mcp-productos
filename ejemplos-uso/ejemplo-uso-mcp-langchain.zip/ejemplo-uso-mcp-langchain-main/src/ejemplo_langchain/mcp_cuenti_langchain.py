from __future__ import annotations

import json
import uuid
from typing import Any

from fastmcp import Client
from fastmcp.client.transports import StreamableHttpTransport
from langchain_core.tools import BaseTool, StructuredTool
from pydantic import BaseModel, Field

MCP_URL = "https://mcp-productos.cuenti.co/mcp/"


class SearchProductsInput(BaseModel):
    query: str = Field(..., description="Texto de busqueda del usuario")
    top_k: int = Field(5, description="Cantidad maxima de resultados")


class LookupBySkuInput(BaseModel):
    sku: str = Field(..., description="SKU exacto del producto")


class SemanticSearchInput(BaseModel):
    dense_vector: list[float] = Field(..., description="Embedding denso precomputado")
    top_k: int = Field(5, description="Cantidad maxima de resultados")


class HybridSearchInput(BaseModel):
    normalized_query: str = Field(..., description="Texto normalizado de la consulta")
    dense_vector: list[float] = Field(..., description="Embedding denso precomputado")
    sparse_indices: list[int] = Field(..., description="Indices del vector sparse")
    sparse_values: list[float] = Field(..., description="Valores del vector sparse")
    top_k: int = Field(5, description="Cantidad maxima de resultados")


class MCPCuentiProductosLangChain:
    def __init__(
        self,
        *,
        api_token: str,
        company_id: str,
        branch_id: str,
        employee_id: str,
    ) -> None:
        self.api_token = api_token
        self.company_id = company_id
        self.branch_id = branch_id
        self.employee_id = employee_id

    def get_tools(self) -> list[BaseTool]:
        return [
            StructuredTool.from_function(
                name="search_products",
                description="Busca productos por texto natural en el catalogo de la sucursal.",
                args_schema=SearchProductsInput,
                coroutine=self.search_products,
            ),
            StructuredTool.from_function(
                name="lookup_by_sku",
                description="Busca un producto por SKU exacto en la sucursal.",
                args_schema=LookupBySkuInput,
                coroutine=self.lookup_by_sku,
            ),
            StructuredTool.from_function(
                name="get_collection_status",
                description="Consulta el estado de la coleccion vectorial del MCP.",
                coroutine=self.get_collection_status,
            ),
            StructuredTool.from_function(
                name="semantic_search_products",
                description="Busqueda semantica usando un dense_vector precomputado.",
                args_schema=SemanticSearchInput,
                coroutine=self.semantic_search_products,
            ),
            StructuredTool.from_function(
                name="hybrid_search_products",
                description="Busqueda hibrida usando dense y sparse precomputados.",
                args_schema=HybridSearchInput,
                coroutine=self.hybrid_search_products,
            ),
        ]

    async def search_products(self, query: str, top_k: int = 5) -> str:
        payload = await self._call_mcp_tool(
            "search_products",
            {
                "company_id": self.company_id,
                "branch_id": self.branch_id,
                "query": query,
                "top_k": top_k,
            },
        )
        return json.dumps(payload, ensure_ascii=False)

    async def lookup_by_sku(self, sku: str) -> str:
        payload = await self._call_mcp_tool(
            "lookup_products",
            {
                "company_id": self.company_id,
                "branch_id": self.branch_id,
                "sku": sku,
            },
        )
        return json.dumps(payload, ensure_ascii=False)

    async def get_collection_status(self) -> str:
        payload = await self._call_mcp_tool("get_collection_status", {})
        return json.dumps(payload, ensure_ascii=False)

    async def semantic_search_products(self, dense_vector: list[float], top_k: int = 5) -> str:
        payload = await self._call_mcp_tool(
            "semantic_search_products",
            {
                "company_id": self.company_id,
                "branch_id": self.branch_id,
                "dense_vector": dense_vector,
                "top_k": top_k,
            },
        )
        return json.dumps(payload, ensure_ascii=False)

    async def hybrid_search_products(
        self,
        normalized_query: str,
        dense_vector: list[float],
        sparse_indices: list[int],
        sparse_values: list[float],
        top_k: int = 5,
    ) -> str:
        payload = await self._call_mcp_tool(
            "hybrid_search_products",
            {
                "company_id": self.company_id,
                "branch_id": self.branch_id,
                "normalized_query": normalized_query,
                "dense_vector": dense_vector,
                "sparse_indices": sparse_indices,
                "sparse_values": sparse_values,
                "top_k": top_k,
            },
        )
        return json.dumps(payload, ensure_ascii=False)

    async def _call_mcp_tool(self, tool_name: str, args: dict[str, Any]) -> dict[str, Any]:
        request_id = str(uuid.uuid4())
        transport = StreamableHttpTransport(
            url=MCP_URL,
            headers={
                "Authorization": f"Bearer {self.api_token}",
                "X-Auth-Token-Empresa": self.company_id,
                "X-Branch-Id": self.branch_id,
                "X-Employee-Id": self.employee_id,
                "X-Request-Id": request_id,
            },
        )

        async with Client(transport) as client:
            result = await client.call_tool(tool_name, args)
            payload = result.data or result.structured_content
            if payload is None:
                raise RuntimeError(f"El MCP no devolvio payload en {tool_name}")
            return payload
