import asyncio
import json
import os
import warnings

from dotenv import load_dotenv

from ejemplo_python import MCPCuentiProductos

warnings.filterwarnings(
    "ignore",
    message=r"authlib\.jose module is deprecated.*",
    category=Warning,
)

REQUIRED_ENV_VARS = [
    "MCP_API_TOKEN",
    "MCP_COMPANY_ID",
    "MCP_BRANCH_ID",
    "MCP_EMPLOYEE_ID",
    "MCP_QUERY",
    "MCP_TOP_K",
]


def get_required_env(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise RuntimeError(f"Falta la variable de entorno requerida: {name}")
    return value


async def main() -> None:
    load_dotenv()

    missing = [name for name in REQUIRED_ENV_VARS if not os.getenv(name)]
    if missing:
        missing_str = ", ".join(missing)
        raise RuntimeError(
            "Faltan variables requeridas en el .env: "
            f"{missing_str}. Revisa .env.example"
        )

    query = get_required_env("MCP_QUERY")
    top_k = int(get_required_env("MCP_TOP_K"))

    async with MCPCuentiProductos(
        api_token=get_required_env("MCP_API_TOKEN"),
        company_id=get_required_env("MCP_COMPANY_ID"),
        branch_id=get_required_env("MCP_BRANCH_ID"),
        employee_id=get_required_env("MCP_EMPLOYEE_ID"),
    ) as mcp_client:
        tools = await mcp_client.list_tools()
        print("Tools disponibles:", tools)
        print("Request ID generado:", mcp_client.request_id)

        payload = await mcp_client.search_products(query=query, top_k=top_k)
        print(json.dumps(payload, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    asyncio.run(main())
