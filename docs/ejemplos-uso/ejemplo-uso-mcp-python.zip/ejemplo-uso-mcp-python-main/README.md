# Cliente MCP en Python (Ejemplo Reutilizable)

Este proyecto muestra una estructura base para consumir un servidor MCP desde Python mediante una clase de alto nivel.

## Estructura

- `src/ejemplo_python/mcp_cuenti_productos.py`: cliente reusable con métodos de alto nivel.
- `main.py`: ejemplo mínimo de uso cargando variables desde `.env`.

## Requisitos

- Python 3.11+

## Instalación

### Con `uv`

```bash
uv sync
```

### Con `venv` + `pip`

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -e .
```

## Configuración

1. Copia el archivo de ejemplo:

```bash
cp .env.example .env
```

2. Completa las variables requeridas en `.env`:

- `MCP_API_TOKEN`
- `MCP_COMPANY_ID`
- `MCP_BRANCH_ID`
- `MCP_EMPLOYEE_ID`
- `MCP_QUERY`
- `MCP_TOP_K`

## Ejecución

### Con `uv`

```bash
uv run main.py
```

### Con `python`

```bash
python main.py
```

## Reutilizar en otro proyecto

Puedes copiar y pegar el módulo del cliente en otro proyecto e invocarlo directamente.

Requisito mínimo en el proyecto destino:

- dependencia `fastmcp`

Ejemplo:

```python
import asyncio
from mcp_cuenti_productos import MCPCuentiProductos


async def run() -> None:
    async with MCPCuentiProductos(
        api_token="<api_token>",
        company_id="<company_id>",
        branch_id="<branch_id>",
        employee_id="<employee_id>",
    ) as mcp:
        result = await mcp.search_products(query="<texto_busqueda>", top_k=5)
        print(result)


asyncio.run(run())
```

Nota: si no se envía `request_id`, la implementación lo genera automáticamente.
