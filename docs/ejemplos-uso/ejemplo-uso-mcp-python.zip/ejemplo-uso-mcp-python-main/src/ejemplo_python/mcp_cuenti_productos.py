from __future__ import annotations

from typing import Any
import uuid

from fastmcp import Client
from fastmcp.client.transports import StreamableHttpTransport


MCP_URL = "https://mcp-productos.cuenti.co/mcp/"


class MCPCuentiProductos:
    def __init__(
        self,
        *,
        api_token: str,
        company_id: str,
        branch_id: str,
        employee_id: str,
        request_id: str | None = None,
    ) -> None:
        self.api_token = api_token
        self.company_id = company_id
        self.branch_id = branch_id
        self.employee_id = employee_id
        self.request_id = request_id or str(uuid.uuid4())
        self._transport = StreamableHttpTransport(
            url=MCP_URL,
            headers={
                "Authorization": f"Bearer {self.api_token}",
                "X-Auth-Token-Empresa": self.company_id,
                "X-Branch-Id": self.branch_id,
                "X-Employee-Id": self.employee_id,
                "X-Request-Id": self.request_id,
            },
        )
        self._client: Client | None = None

    async def __aenter__(self) -> "MCPCuentiProductos":
        self._client = Client(self._transport)
        await self._client.__aenter__()
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        if self._client is not None:
            await self._client.__aexit__(exc_type, exc, tb)
            self._client = None

    def _require_client(self) -> Client:
        if self._client is None:
            raise RuntimeError(
                "El cliente no esta inicializado. Usa 'async with MCPCuentiProductos(...)'."
            )
        return self._client

    async def list_tools(self) -> list[str]:
        client = self._require_client()
        tools = await client.list_tools()
        return [tool.name for tool in tools]

    async def search_products(self, query: str, top_k: int = 5) -> dict[str, Any]:
        client = self._require_client()
        result = await client.call_tool(
            "search_products",
            {
                "company_id": self.company_id,
                "branch_id": self.branch_id,
                "query": query,
                "top_k": top_k,
            },
        )
        payload = result.data or result.structured_content
        if payload is None:
            raise RuntimeError("El MCP no devolvio payload en search_products")
        return payload

    async def lookup_by_sku(self, sku: str) -> dict[str, Any]:
        client = self._require_client()
        result = await client.call_tool(
            "lookup_products",
            {
                "company_id": self.company_id,
                "branch_id": self.branch_id,
                "sku": sku,
            },
        )
        payload = result.data or result.structured_content
        if payload is None:
            raise RuntimeError("El MCP no devolvio payload en lookup_by_sku")
        return payload

    async def semantic_search_products(
        self,
        dense_vector: list[float],
        top_k: int = 5,
    ) -> dict[str, Any]:
        client = self._require_client()
        result = await client.call_tool(
            "semantic_search_products",
            {
                "company_id": self.company_id,
                "branch_id": self.branch_id,
                "dense_vector": dense_vector,
                "top_k": top_k,
            },
        )
        payload = result.data or result.structured_content
        if payload is None:
            raise RuntimeError("El MCP no devolvio payload en semantic_search_products")
        return payload

    async def hybrid_search_products(
        self,
        normalized_query: str,
        dense_vector: list[float],
        sparse_indices: list[int],
        sparse_values: list[float],
        top_k: int = 5,
    ) -> dict[str, Any]:
        client = self._require_client()
        result = await client.call_tool(
            "hybrid_search_products",
            {
                "company_id": self.company_id,
                "branch_id": self.branch_id,
                "normalized_query": normalized_query,
                "dense_vector": dense_vector,
                "sparse_indices": sparse_indices,
                "sparse_values": sparse_values,
                "top_k": top_k,
            },
        )
        payload = result.data or result.structured_content
        if payload is None:
            raise RuntimeError("El MCP no devolvio payload en hybrid_search_products")
        return payload
